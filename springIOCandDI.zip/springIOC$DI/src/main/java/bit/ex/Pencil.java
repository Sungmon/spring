package bit.ex;

public interface Pencil {
	String use(String p); //문장앞에 public abstract 생략가능.외우기**
	
}
