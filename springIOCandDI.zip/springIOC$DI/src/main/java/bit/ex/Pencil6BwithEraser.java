package bit.ex;

public class Pencil6BwithEraser implements Pencil {

	public String use(String p) {
		// TODO Auto-generated method stub
		p = "6B연필과 지우개입니다.";
		return p;
	}
	
//	public void use(String p) {
//		// TODO Auto-generated method stub
//		System.out.println("6B 굵기로 쓰이고, 지우개가 있습니다.");
//	}
}
