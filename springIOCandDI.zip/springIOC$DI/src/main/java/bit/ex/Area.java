package bit.ex;

public interface Area {
	
		double getArea(double a, double b);
}
