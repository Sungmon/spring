package bit.ex;

public class Pencil6B implements Pencil {

	public String use(String p) {
		// TODO Auto-generated method stub
		
		p = "6B 연필입니다.";
		return p;
	}
	
//	//use()함수의 오버라이딩.
//	public void use(String p) {
//		// TODO Auto-generated method stub
//		System.out.println("6B굵기로 쓰입니다.");
//	}
}
